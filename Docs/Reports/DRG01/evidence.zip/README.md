# DRG01 evidence 2026-11-07
Local only; no AWS deployment or two physical PCs.
report.vi.md and report.json beside this archive explain scope and limitations.
Wss enum in loopback evidence means ws://127.0.0.1, not public TLS.
Airdrop socket fixture uses confirmed damage; offline-combat uses real TryAttack.
Unity EditMode: 1129/1134; five unrelated failures retained. PlayMode:150/150.
Superseded WorldNetwork log is an earlier fixture pickup race; two final Mixed runs pass37/37.
Runtime benchmark is separate from short Windows flow and is not AWS256MiB validation.
Source user modifications are preserved; no commit/push.

Post-DRG repair: EditMode1136/1136 and PlayMode150/150 PASS. See editmode-repair/. Earlier five failures are resolved. Windows build predates this repair and was not rebuilt. Editor Boot stopped; EnterPlayModeOptions restored to None.
