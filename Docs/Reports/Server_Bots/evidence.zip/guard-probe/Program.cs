using System.Net.WebSockets;
using System.Text.Json;
using JungleBackend.Protocol;
using LiteNetLib.Utils;
var checks=new List<object>();
foreach(var item in new[]{(Version:NetworkProtocol.Version3,Expected:"AuthRequired"),(Version:NetworkProtocol.Version4,Expected:"InvalidTicket")})
{
    using var stop=new CancellationTokenSource(TimeSpan.FromSeconds(15));
    using var socket=new ClientWebSocket();
    await socket.ConnectAsync(new Uri("wss://junglemaze.duckdns.org/game"),stop.Token);
    var request=NetworkProtocol.WriteConnect(JoinAuthMode.RoomCode,"Denied","GuardProbe",item.Version,Guid.NewGuid(),ticket:item.Version==4?new string('a',64):"");
    await socket.SendAsync(new ArraySegment<byte>(request.CopyData()),WebSocketMessageType.Binary,true,stop.Token);
    var buffer=new byte[512];var result=await socket.ReceiveAsync(new ArraySegment<byte>(buffer),stop.Token);
    var reader=new NetDataReader(buffer,0,result.Count);
    var rejected=NetworkProtocol.TryReadStringMessage(reader,NetworkProtocol.JoinRejected,512,128,out var reason);
    if(!rejected||reason!=item.Expected)throw new Exception("Unexpected account guard result: "+reason);
    checks.Add(new{version=item.Version,expected=item.Expected,status="PASS"});
    socket.Abort();
}
var json=JsonSerializer.Serialize(new{status="PASS",transport="Wss",endpoint="junglemaze.duckdns.org",checks},new JsonSerializerOptions{WriteIndented=true});
File.WriteAllText("D:/Unity/Lastaway/.utmp/server-bots-20261103/aws-r2-account-guard.json",json);Console.WriteLine(json);
