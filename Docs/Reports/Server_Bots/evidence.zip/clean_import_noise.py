from pathlib import Path
import subprocess, re
root = Path('D:/Unity/Lastaway').resolve()
out = root / '.utmp/server-bots-20261103'
def git(*args): return subprocess.run(['git','-c','core.safecrlf=false',*args],cwd=root,check=True,capture_output=True).stdout
patch = git('diff','--binary','--','Assets/Imported/JSurviv')
(out/'unity-importer-noise.patch').write_bytes(patch)
allowed = {'serializedVersion','buildTarget','maxTextureSize','resizeAlgorithm','textureFormat','textureCompression','compressionQuality','crunchedCompression','allowsAlphaSplitting','overridden','ignorePlatformSupport','androidETC2FallbackOverride','forceMaximumCompressionQuality_BC6H_BC7'}
paths=[]
for chunk in patch.decode('utf-8').split('diff --git ')[1:]:
    lines=chunk.splitlines()
    if any(x.startswith('-') and not x.startswith('---') for x in lines): raise RuntimeError('Non-additive importer change; preserve for review')
    additions=[x[1:] for x in lines if x.startswith('+') and not x.startswith('+++')]
    for line in additions:
        key=line.strip().removeprefix('- ').split(':',1)[0]
        if key not in allowed: raise RuntimeError('Unexpected importer key: '+key)
        if key=='buildTarget' and line.split(':',1)[1].strip() not in ('WebGL','WindowsStoreApps'): raise RuntimeError('Unexpected target')
        if key=='overridden' and line.split(':',1)[1].strip()!='0': raise RuntimeError('Actual platform override')
    # Obtain exact Unicode paths from Git's NUL-separated inventory below, not quoted patch headers.
changed=git('diff','--name-only','-z','--','Assets/Imported/JSurviv').decode('utf-8').split('\0')
for rel in filter(None,changed):
    p=(root/rel).resolve()
    if not p.is_relative_to(root/'Assets/Imported/JSurviv') or p.suffix!='.meta': raise RuntimeError('Outside importer scope')
    paths.append(rel)
if paths:
    specs=out/'importer-paths.nul'; specs.write_bytes(('\0'.join(paths)+'\0').encode('utf-8'))
    git('restore','--worktree','--pathspec-from-file='+str(specs),'--pathspec-file-nul')
print('Restored generated, non-overridden texture platform entries:',len(paths))
