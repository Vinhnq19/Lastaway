$window=Get-Content -LiteralPath 'D:/Unity/Lastaway/.utmp/server-bots-20261103/aws-window-r2.json' -Raw | ConvertFrom-Json
$env:AWS_ROOM_DEADLINE_UTC=([DateTime]::Parse($window.hardDeadlineUtc).ToUniversalTime().AddSeconds(-60)).ToString('o')
$env:NET_TEST_BOT_COUNT='4'
$env:NET_TEST_MAP_ID='bai-da'
& 'D:/Unity/Lastaway/Backend/Deploy/test-unity-remote.ps1' -Player 'D:/Unity/Lastaway/Builds/Windows-Bots-6000.3.15f1/Lastaway.exe' -Scenario 'D:/Unity/Lastaway/.utmp/server-bots-20261103/bots6-flow.json' -OutputDirectory 'D:/Unity/Lastaway/.utmp/server-bots-20261103/aws-r2-2plus4-auto' -Clients 2 -ForceAutoFallback
