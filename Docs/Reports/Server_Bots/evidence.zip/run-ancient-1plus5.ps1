$env:NET_TEST_BOT_COUNT='5'
$env:NET_TEST_MAP_ID='di-tich-co'
$env:NET_TRANSPORT='Udp'
& 'D:/Unity/Lastaway/Backend/Deploy/test-unity-remote.ps1' -Player 'D:/Unity/Lastaway/Builds/Windows-Bots-6000.3.15f1/Lastaway.exe' -Scenario 'D:/Unity/Lastaway/.utmp/server-bots-20261103/bots6-flow.json' -OutputDirectory 'D:/Unity/Lastaway/.utmp/server-bots-20261103/local-ancient-1plus5' -ApiBaseUrl 'http://127.0.0.1:5000' -Local -Clients 1
