import json, subprocess, time
from pathlib import Path
root=Path('D:/Unity/Lastaway'); out=root/'.utmp/server-bots-20261103'
results=[]
for name in ['MatchChecks','MatchResultChecks','InventoryChecks','CombatChecks','WorldChecks','MapCatalogChecks','TelemetryChecks','NetworkChecks','DualTransportChecks','GameplayNetworkChecks','WorldNetworkChecks']:
    start=time.monotonic()
    try:
        r=subprocess.run(['dotnet','run','--project',f'Backend/Tests/{name}/{name}.csproj'],cwd=root,capture_output=True,timeout=180)
        (out/(name+'.log')).write_bytes(r.stdout+r.stderr)
        result={'suite':name,'status':'PASS' if r.returncode==0 else 'FAIL','exitCode':r.returncode,'seconds':round(time.monotonic()-start,2)}
    except subprocess.TimeoutExpired as e:
        (out/(name+'.log')).write_bytes((e.stdout or b'')+(e.stderr or b''));result={'suite':name,'status':'FAIL','reason':'timeout180s'}
    results.append(result);(out/'regression.json').write_text(json.dumps(results,indent=2),encoding='utf-8');print(json.dumps(result),flush=True)
