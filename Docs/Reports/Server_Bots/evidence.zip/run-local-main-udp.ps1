$env:NET_TEST_BOT_COUNT='9'
$env:NET_TEST_MAP_ID='bai-da'
$env:NET_TRANSPORT='Udp'
& 'D:/Unity/Lastaway/Backend/Deploy/test-unity-remote.ps1' -Player 'D:/Unity/Lastaway/Builds/Windows-Bots-6000.3.15f1/Lastaway.exe' -Scenario 'D:/Unity/Lastaway/Backend/Tests/OnlineReadiness/scenarios/bots10-main.json' -OutputDirectory 'D:/Unity/Lastaway/.utmp/server-bots-20261103/local-1plus9-udp' -ApiBaseUrl 'http://127.0.0.1:5000' -Local -Clients 1
