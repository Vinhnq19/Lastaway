import json,csv,hashlib,zipfile,shutil,re,subprocess,datetime
from pathlib import Path
root=Path.cwd();src=root/'.utmp/server-bots-20261103';out=root/'Docs/Reports/Server_Bots';out.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
cases=[('local-1plus5-preflight','Local','pre-hotfix'),('local-1plus5-no-uia','Local','pre-hotfix'),('local-1plus9-main','Local','pre-hotfix'),('local-1plus9-udp','Local','pre-hotfix'),('local-1plus9-ws-keepawake','Local','pre-hotfix'),('local-1plus9-ws-isolated','Local','pre-hotfix'),('local-ancient-1plus5-after-quota','Local','pre-hotfix'),('local-ancient-2plus4','Local','pre-hotfix'),('local-rocks-1plus5','Local','pre-hotfix'),('local-rocks-2plus4','Local','pre-hotfix'),('local-hazard-flow','Local','r2'),('aws-1plus9-wss','AWS','r1'),('aws-2plus4-auto','AWS','r1'),('aws-r2-1plus9-wss','AWS','r2'),('aws-r2-2plus4-auto','AWS','r2'),('aws-r2-udp-probe','AWS','r2')]
runs=[];rows=[]
for case,env,version in cases:
    folder=src/case;f=folder/'players/report.json'
    if not f.exists():continue
    r=read(f);item=dict(case=case,environment=env,serverStage=version,status=r['status'],clients=[])
    if (folder/'report.json').exists():item['apiChecks']=read(folder/'report.json')
    for c in r['clients']:
        e=read(folder/'players'/c['evidenceFile']);m=e.get('metrics',{});item['clients'].append(dict(status=c['status'],exitCode=c['exitCode'],transport=c['selectedTransport'],fallbackReason=c.get('fallbackReason'),metrics=m,assertions=e.get('assertions',[])))
        rows.append(dict(case=case,environment=env,serverStage=version,client=c['id'],status=c['status'],exitCode=c['exitCode'],transport=c['selectedTransport'],connectedSeconds=m.get('connectedSeconds',0),inputHz=m.get('inputHz',0),snapshotHz=m.get('snapshotHz',0),rttP50Ms=m.get('rttP50Ms',0),rttP95Ms=m.get('rttP95Ms',0),rttP99Ms=m.get('rttP99Ms',0),pongTimeouts=m.get('pongTimeouts',0),completedMatches=m.get('completedMatches',0),physicalDeviceCount=1))
    runs.append(item)
summary=dict(schemaVersion=1,updatedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PASS_WITH_LIMITS',botModuleChecks=159,matchResultChecks=85,unityEditMode=dict(passed=910,total=910),unityPlayMode=dict(passed=133,total=133),configuration=dict(roomCapacity=10,rooms=5,totalParticipants=50,minPlayers=6,accountHandshake=4,gameplayProtocol=3,offlineBots=False),environment=read(src/'environment-final.json'),backendRegression=read(src/'regression.json'),performance=dict(localUdp=read(src/'performance-summary.json')['local-udp-server.log'],localWs=read(src/'local-ws-isolated-performance.json'),localStressFailed=read(src/'stress-final-performance.json'),localStressLatest=read(src/'stress-isolated-performance.json'),awsBaselineFailed=read(src/'aws-baseline-performance.json'),awsLatest=read(src/'aws-r2-performance.json')),persistence=dict(local=read(src/'persistence-real.json'),aws=read(src/'aws-r2-preservation.json')),accountGuard=read(src/'aws-r2-account-guard.json'),awsClosure=read(src/'aws-window-r2.json'),runs=runs,notTested=['Two physical PCs and separate-account end-to-end play','Human judgement of bot difficulty/fun','Five rooms / fifty participants on AWS','Offline bots, teams and multiple difficulties'],limits=['Connected300s includes lobby/results/replay; input rate measured only while actor sends input.','Older failed/contaminated runs retained; latest PASS does not erase them.','Tick spikes and WAN RTT remain; this is not a guarantee of unlimited load or perfectly smooth play.','Automated multi-client launcher uses a shared QA account per run; distinct physical players/accounts need checklist.'])
(out/'report.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
with (out/'summary.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
shots=out/'screenshots';shots.mkdir(exist_ok=True)
for name,rel in [('lobby.png','local-ancient-1plus5-after-quota/players/evidence-client-1.json.lobby.png'),('aws-game.png','aws-r2-1plus9-wss/players/evidence-client-1.json.png'),('aws-result.png','aws-r2-1plus9-wss/players/evidence-client-1.json.result.png')]:shutil.copyfile(src/rel,shots/name)
secret_values=[]
for line in (root/'Backend/.env').read_text(encoding='utf-8-sig').splitlines():
    if '=' in line:
        k,v=line.split('=',1)
        if any(s in k.upper() for s in ['TOKEN','PASSWORD','SIGNING_KEY','ROOM_CODE']) and len(v.strip())>=8:secret_values.append(v.strip().encode())
files=[]
for p in src.rglob('*'):
    if not p.is_file() or any(v in p.relative_to(src).parts for v in ['bin','obj','stress-publish','stress-publish-final','unity-test-noise']):continue
    if p.suffix.lower() not in ['.json','.csv','.log','.png','.ps1','.py'] and not ('guard-probe' in p.parts and p.suffix in ['.cs','.csproj']):continue
    data=p.read_bytes()
    if any(v in data for v in secret_values):raise RuntimeError('Secret scan failed; content withheld: '+p.name)
    if p.suffix.lower() not in ['.png'] and re.search(rb'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',data):raise RuntimeError('JWT scan failed; withheld: '+p.name)
    files.append(p)
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,p.relative_to(src).as_posix())
    for rel in ['release.tar.gz.sha256']:
        z.write(root/'Backend/out/aws-bots-20261105-r2'/rel,'release-r2/'+rel)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None and len(z.namelist())==len(files)+1
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(out/'evidence.zip.sha256').write_text(sha+'  evidence.zip\n',encoding='utf-8')
print(json.dumps(dict(runs=len(runs),clientRows=len(rows),evidenceFiles=len(files)+1,archiveMiB=round(archive.stat().st_size/1048576,2),sha256=sha),indent=2))
