import copy, datetime, json, subprocess, urllib.request, urllib.error, uuid
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'.utmp/server-bots-20261103/persistence-real.json'
def mongo(code):
    return subprocess.check_output(['docker','exec','backend-mongo-1','mongosh','--quiet','jungle_maze','--eval',code],text=True).strip()
env=json.loads(subprocess.check_output(['docker','inspect','backend-api-1','--format','{{json .Config.Env}}'],text=True))
secret=next(x.split('=',1)[1] for x in env if x.startswith('MATCH_RESULT_TOKEN='))
assert len(secret.encode())>=32
mid=str(uuid.uuid4()); now=datetime.datetime.now(datetime.timezone.utc); start=now-datetime.timedelta(seconds=60)
payload=dict(matchId=mid,roomId=str(uuid.uuid4()),configVersion='1.1.0',startUtc=start.isoformat(),endUtc=now.isoformat(),reason='LastAlive',matchKind='WithBots',participants=[dict(playerSessionId='human-fixture',displayName='Test human',rank=2,kills=0,survivalSeconds=45,profileKey='account:persistence-fixture',isBot=False),dict(playerSessionId='bot-fixture',displayName='BOT fixture',rank=1,kills=1,survivalSeconds=60,profileKey=None,isBot=True)])
checks=[]
def check(name, value):
    checks.append(dict(name=name,status='PASS' if value else 'FAIL'))
    assert value,name

def post(body):
    request=urllib.request.Request('http://127.0.0.1:5000/internal/match-results',data=json.dumps(body).encode(),headers={'Content-Type':'application/json','X-Match-Result-Token':secret})
    try:
        with urllib.request.urlopen(request,timeout=12) as r: return r.status
    except urllib.error.HTTPError as e: return e.code
try:
    check('actual Mongo insert',post(payload)==201)
    check('identical replay idempotent',post(payload)==200)
    altered=copy.deepcopy(payload);altered['participants'][0]['kills']=1
    check('same MatchId changed result conflict',post(altered)==409)
    invalid=copy.deepcopy(payload);invalid['participants'][1]['profileKey']='account:forged-bot'
    check('bot cannot own account profile',post(invalid)==400)
    invalid=copy.deepcopy(payload);invalid['matchKind']='HumanOnly'
    check('HumanOnly cannot contain bots',post(invalid)==400)
    check('one Mongo document',int(mongo('db.matches.countDocuments({_id:'+json.dumps(mid)+'})'))==1)
    with urllib.request.urlopen('http://127.0.0.1:5000/api/matches/'+mid+'/leaderboard',timeout=12) as r: board=json.load(r)
    check('public leaderboard WithBots/BOT winner',board['matchKind']=='WithBots' and board['players'][0]['isBot'])
    check('public leaderboard hides profiles',all('profileKey' not in p for p in board['players']))
    live=json.loads(mongo('JSON.stringify(db.matches.find({MatchKind:"WithBots",_id:{$ne:'+json.dumps(mid)+'}}).sort({EndUtc:-1}).limit(3).toArray().map(m=>({kind:m.MatchKind,count:m.Participants.length,bots:m.Participants.filter(p=>p.IsBot).length,botProfiles:m.Participants.filter(p=>p.IsBot&&p.ProfileKey!=null).length})))'))
    check('real Unity rounds persisted WithBots',len(live)>0 and any(x['count']==10 and x['bots']==9 for x in live))
    check('real bots have no profile key',all(x['botProfiles']==0 for x in live))
    report=dict(status='PASS',checks=checks,recentUnityRounds=live,fixtureRemoved=False)
finally:
    deleted=int(mongo('db.matches.deleteOne({_id:'+json.dumps(mid)+'}).deletedCount'))
    if 'report' not in locals():report=dict(status='FAIL',checks=checks)
    report['fixtureRemoved']=deleted==1
    out.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
