$window=Get-Content -LiteralPath 'D:/Unity/Lastaway/.utmp/server-bots-20261103/aws-window-r2.json' -Raw | ConvertFrom-Json
$env:AWS_ROOM_DEADLINE_UTC=([DateTime]::Parse($window.hardDeadlineUtc).ToUniversalTime().AddSeconds(-60)).ToString('o')
$env:NET_TEST_BOT_COUNT='9'
$env:NET_TEST_MAP_ID='bai-da'
$env:NET_TRANSPORT='Wss'
& 'D:/Unity/Lastaway/Backend/Deploy/test-unity-remote.ps1' -Player 'D:/Unity/Lastaway/Builds/Windows-Bots-6000.3.15f1/Lastaway.exe' -Scenario 'D:/Unity/Lastaway/Backend/Tests/OnlineReadiness/scenarios/bots10-main.json' -OutputDirectory 'D:/Unity/Lastaway/.utmp/server-bots-20261103/aws-r2-1plus9-wss' -Clients 1
